// dllVI50.cpp�: d�finit les fonctions export�es pour l'application DLL.

#include "stdafx.h"
#include <QHHeadersWin32.h>
#include <HD/hd.h>
#include <HDU/hduError.h>
#include <HDU/hduVector.h>

DeviceSpace* OmniSpace;
//Cursor* cursor;
HHD ghHD;
HDSchedulerHandle gSchedulerCallback;
hduVector3Dd position;//, positionOnClickButton2, previousPosition;

hduVector3Dd forceActuelle;
hduVector3Dd forceIni;
bool button1;
bool button2;

//bool activatedHD = false;
bool camera = false;
bool hand = false;

HDdouble gVibrationAmplitude;

extern "C" HDCallbackCode HDCALLBACK compute(void *pUserData){
	hdBeginFrame(ghHD);

	// on r�cup�re la position
//	previousPosition = position;
	hdGetDoublev(HD_CURRENT_POSITION, position);

	// on fixe la force
	hdSetDoublev(HD_CURRENT_FORCE, forceActuelle);

	// onr�cup�re l'�tat des boutons
	HDint button = 0;
	hdGetIntegerv(HD_CURRENT_BUTTONS,&button);
	
	button1 = ((button & HD_DEVICE_BUTTON_1)==HD_DEVICE_BUTTON_1);
	button2 = ((button & HD_DEVICE_BUTTON_2)==HD_DEVICE_BUTTON_2);

	/*
	if(button1){
		camera = false;
		hand = true;
	}
	else if(button2){
		camera = true;
		hand = false;
	}else{
		camera = false;
		hand = false;		
	}*/

	hdEndFrame(ghHD);

	return HD_CALLBACK_CONTINUE;
}

extern "C" __declspec(dllexport) int init()  
{  
	//if(!activatedHD){
	HDErrorInfo error;
	gSchedulerCallback = HD_INVALID_HANDLE;
	ghHD = HD_INVALID_HANDLE;


	ghHD = hdInitDevice(HD_DEFAULT_DEVICE);
	
    if (HD_DEVICE_ERROR(error = hdGetError()))
	{
		return -1;
	}
/*
	hdEnable(HD_CURRENT_BUTTONS);
	hdEnable(HD_CURRENT_POSITION);*/
	hdEnable(HD_FORCE_OUTPUT);
    hdEnable(HD_MAX_FORCE_CLAMPING);
	
	/*
	gVibrationAmplitude = 0.75;
	hdGetDoublev(HD_NOMINAL_MAX_CONTINUOUS_FORCE, &gVibrationAmplitude );
	*/
	forceIni[0]= 0;
	forceIni[1]= 0;
	forceIni[2]= 0;

	forceActuelle = forceIni;
	gSchedulerCallback = hdScheduleAsynchronous(compute, (void*)0,HD_MAX_SCHEDULER_PRIORITY);

	hdStartScheduler();

	
	if (HD_DEVICE_ERROR(error = hdGetError()))
		return -2;
	
	//activatedHD = true;

	
	return 0;/*}
	return -3;*/
} 

extern "C" __declspec(dllexport) void exitHD(){
	/*if(activatedHD){

		activatedHD = false;*/

		hdStopScheduler();
		hdUnschedule(gSchedulerCallback);

		hdDisableDevice(ghHD);
	//}
}


extern "C" __declspec(dllexport) double getX()  
{  
	return (double) position[0];
} 

extern "C" __declspec(dllexport) double getY()  
{  
	return (double) position[1];
} 

extern "C" __declspec(dllexport) double getZ()  
{  
	return (double) position[2];
} 

/*
extern "C" __declspec(dllexport) double getRelativeXForCamera()  
{  
	if(camera)
		return (double) position[0] - positionOnClickButton2[0];
	return 0;
} 

extern "C" __declspec(dllexport) double getRelativeYForCamera()  
{  
	if(camera)
		return (double) position[1] - positionOnClickButton2[1];
	return 0;
} 

extern "C" __declspec(dllexport) double getRelativeZForCamera()  
{  
	if(camera)
		return (double) position[2] - positionOnClickButton2[2];
	return 0;
} 

extern "C" __declspec(dllexport) double getRelativeXForHand()  
{  
	return (double) position[0] - previousPosition[0];
} 

extern "C" __declspec(dllexport) double getRelativeYForHand()  
{  
	return (double) position[1] - previousPosition[1];
} 

extern "C" __declspec(dllexport) double getRelativeZForHand()  
{  
	return (double) position[2] - previousPosition[2];
} 
*/
extern "C" __declspec(dllexport) void setForceOnAxisX(double x, double y, double z)  
{  
	forceActuelle[0] = x;
	forceActuelle[1] = y;
	forceActuelle[2] = z;
} 

extern "C" __declspec(dllexport) bool isButton1Activate()  
{  
	return  button1;
} 

extern "C" __declspec(dllexport) bool isButton2Activate()  
{  
//	positionOnClickButton2 = position;
	return button2;
}

extern "C" __declspec(dllexport) void reInitForce(){
	forceActuelle = forceIni;
}

/*extern "C" __declspec(dllexport) bool isActivatedHD(){
	return activatedHD;
}*/


