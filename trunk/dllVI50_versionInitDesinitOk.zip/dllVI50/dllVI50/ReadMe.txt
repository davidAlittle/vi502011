========================================================================
    BIBLIOTH&Egrave;QUE DE LIENS DYNAMIQUES&nbsp;: Vue d'ensemble du projet dllVI50
========================================================================

AppWizard a cr&eacute;&eacute; cette DLL dllVI50 pour vous.

Ce fichier contient un r&eacute;sum&eacute; des &eacute;l&eacute;ments contenus dans chaque fichier qui
constitue votre application dllVI50.


dllVI50.vcproj
    Il s'agit du fichier projet principal pour les projets VC++ g&eacute;n&eacute;r&eacute;s &agrave; l'aide d'un Assistant Application.
    Il contient des informations relatives &agrave; la version de Visual&nbsp;C++ qui a g&eacute;n&eacute;r&eacute; le fichier,
    ainsi que des informations sur les plateformes, configurations et fonctionnalit&eacute;s du projet
    d'un Assistant Application.

dllVI50.cpp
    Il s'agit du fichier source principal de la DLL.

	Une fois cr&eacute;&eacute;e, cette DLL n'exporte aucun symbole. Il en r&eacute;sulte qu'elle
	ne produira pas un fichier .lib lors de la g&eacute;n&eacute;ration. Si vous souhaitez que ce projet
	soit une d&eacute;pendance d'un autre projet, vous devez
	ajouter du code pour exporter des symboles &agrave; partir de la DLL afin qu'une biblioth&egrave;que d'exportation
	soit cr&eacute;&eacute;e ou vous pouvez d&eacute;finir la propri&eacute;t&eacute; Ignore Input Library &agrave; la valeur Yes
	dans la page de propri&eacute;t&eacute;s G&eacute;n&eacute;ral du dossier &Eacute;diteur de liens de la bo&icirc;te de dialogue Pages de propri&eacute;t&eacute;s
	du projet.

/////////////////////////////////////////////////////////////////////////////
Autres fichiers standard&nbsp;:

StdAfx.h, StdAfx.cpp
    Ces fichiers sont utilis&eacute;s pour g&eacute;n&eacute;rer un fichier d'en-t&ecirc;te pr&eacute;compil&eacute; (PCH)
    nomm&eacute; dllVI50.pch et un fichier de types pr&eacute;compil&eacute;s nomm&eacute; StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Autres remarques&nbsp;:

AppWizard utilise des commentaires "TODO:" pour indiquer les parties du code source o&ugrave; vous
devrez ajouter ou modifier du code.

/////////////////////////////////////////////////////////////////////////////
