/******************************************************************************

Copyright (c) 2004 SensAble Technologies, Inc. All rights reserved.

3D Touch(TM) SDK, HDAPI Source Code Examples. The material embodied in
this software and use of this software is subject to the terms and
conditions of the clickthrough Development License Agreement.

Send your questions, comments or bugs to: support@sensable.com

Module name:

  HapticDeviceManager.cpp

Description:

  Haptic Device Manager class implementation.

*******************************************************************************/


#include "IHapticDeviceManager.h"

#include <HD/hd.h>

#include <HDU/hdu.h>
#include <HDU/hduMatrix.h>
#include <HDU/hduVector.h>
#include <HDU/hduHapticDevice.h>

#include <ode/ode.h>
#include <drawstuff/drawstuff.h>

#include <GL/gl.h>

#if defined(_MSC_VER) && (_MSC_VER > 1300)
#include <iostream>
using namespace std;
#else
#include <iostream.h>
#endif

#include <assert.h>

#define CURSOR_RADIUS   0.05f

// for 1.0/1.01 compatability
#ifndef HDCALLBACK
#define HDCALLBACK
#endif

namespace
{

struct ViewpointState
{
    ViewpointState()
    {
        memset(m_xyz, 0, sizeof m_xyz);
        memset(m_hpr, 0, sizeof m_hpr);
    }

    bool operator==(const ViewpointState &rhs)
    {
        return memcmp(m_xyz, rhs.m_xyz, sizeof m_xyz) == 0 &&
            memcmp(m_hpr, rhs.m_hpr, sizeof m_hpr) == 0;
    }

    bool operator!=(const ViewpointState &rhs)
    {
        return !(*this == rhs);
    }

    float m_xyz[3];
    float m_hpr[3];
};
 
class HapticDeviceManager : public IHapticDeviceManager
{
public:

    HapticDeviceManager();
    virtual ~HapticDeviceManager();

    virtual bool init(dWorldID world, dSpaceID space);
    virtual bool shutdown();

    virtual void updateSimulation();
    virtual void updateDisplay();

    IHapticDevice * const getHapticDevice(IHapticDevice::InterfaceType type);
    const IHapticDevice * const getHapticDevice(IHapticDevice::InterfaceType type) const;

    void setIsManipulating(bool bManipulating) { m_bManipulating = bManipulating; }
    bool isManipulating() const { return m_bManipulating; }

protected:
    
    void updateWorkspace();
    void updateCursor();

    void startManipulation(const IHapticDevice::IHapticDeviceState * const pState);
    void updateManipulation();
    void stopManipulation();

    static void buttonDownCallbackHT(IHapticDevice::EventType event,
                                     const IHapticDevice::IHapticDeviceState * const pState,
                                     void *pUserData);
    static void buttonDownCallbackGT(IHapticDevice::EventType event,
                                     const IHapticDevice::IHapticDeviceState * const pState,
                                     void *pUserData);
    static void buttonUpCallbackGT(IHapticDevice::EventType event,
                                   const IHapticDevice::IHapticDeviceState * const pState,
                                   void *pUserData);

    static HDCallbackCode HDCALLBACK deviceUpdateCallback(void *pUserData);
    static HDCallbackCode HDCALLBACK setHapticDeviceWorkspace(void *pUserData);
    static HDCallbackCode HDCALLBACK startManipulationCallback(void *pUserData);
    static HDCallbackCode HDCALLBACK stopManipulationCallback(void *pUserData);
    static HDCallbackCode HDCALLBACK updateManipulationCallback(void *pUserData);

private:    

    dSpaceID m_space;
    dWorldID m_world;
    dGeomID m_geom;

    bool m_bManipulating;

    ViewpointState m_currentView;
    hduMatrix m_workspaceXform;
    hduMatrix m_offsetXform;

    HHD m_hHD;
    HDSchedulerHandle m_hUpdateHandle;
    IHapticDevice *m_pHapticDeviceHT;
    IHapticDevice *m_pHapticDeviceGT;
};

HapticDeviceManager::HapticDeviceManager() :
    m_hHD(0),
    m_pHapticDeviceHT(0),
    m_pHapticDeviceGT(0),
    m_space(0),
    m_geom(0),
    m_bManipulating(false)
{
}

HapticDeviceManager::~HapticDeviceManager()
{
}

} /* anonymous namespace */

IHapticDeviceManager *IHapticDeviceManager::create()
{
    return new HapticDeviceManager;
}


void IHapticDeviceManager::destroy(IHapticDeviceManager *&pInterface)
{
    if (pInterface)
    {
        HapticDeviceManager *pImp = static_cast<HapticDeviceManager *>(pInterface);
        delete pImp;
        pInterface = 0;
    }
}

/******************************************************************************
 Setup / Cleanup
******************************************************************************/
bool HapticDeviceManager::init(dWorldID world, dSpaceID space)
{
    m_hHD = hdInitDevice(HD_DEFAULT_DEVICE);
    if (HD_DEVICE_ERROR(hdGetError()))
        return false;

    hdEnable(HD_FORCE_OUTPUT);
    hdEnable(HD_MAX_FORCE_CLAMPING);

    m_pHapticDeviceHT = IHapticDevice::create(IHapticDevice::HAPTIC_THREAD_INTERFACE, m_hHD);
    m_pHapticDeviceGT = IHapticDevice::create(IHapticDevice::GRAPHIC_THREAD_INTERFACE, m_hHD);

    m_hUpdateHandle = hdScheduleAsynchronous(deviceUpdateCallback, this,
                                             HD_MAX_SCHEDULER_PRIORITY);
    hdStartScheduler();
    if (HD_DEVICE_ERROR(hdGetError()))
        return false;

    /* Setup callback functions with HapticDeviceGT and HapticDeviceHT so that 
       we can be notified about button presses. */
    m_pHapticDeviceGT->setCallback(IHapticDevice::BUTTON_1_DOWN, buttonDownCallbackGT, this);
    m_pHapticDeviceGT->setCallback(IHapticDevice::BUTTON_1_UP, buttonUpCallbackGT, this);
    m_pHapticDeviceHT->setCallback(IHapticDevice::BUTTON_1_DOWN, buttonDownCallbackHT, this);

    /* A useful container for accessing geometry and bodies in the ODE 
       simulation. */
    m_space = space;
    m_world = world;

    return true;
}


bool HapticDeviceManager::shutdown()
{
    hdScheduleSynchronous(stopManipulationCallback, this,
                          HD_DEFAULT_SCHEDULER_PRIORITY);

    hdStopScheduler();
    hdUnschedule(m_hUpdateHandle);
    m_hUpdateHandle = 0;

    IHapticDevice::destroy(m_pHapticDeviceHT);
    IHapticDevice::destroy(m_pHapticDeviceGT);
    hdDisableDevice(m_hHD);

    HDErrorInfo error;
    if (HD_DEVICE_ERROR(error = hdGetError()))
    {
        cout << "HapticDeviceManager::shutdown encountered error: " << error.errorCode << endl;
    }
        
    return true;
}

IHapticDevice * const HapticDeviceManager::getHapticDevice(
    IHapticDevice::InterfaceType type)
{
    switch (type)
    {
        case IHapticDevice::HAPTIC_THREAD_INTERFACE: return m_pHapticDeviceHT;
        case IHapticDevice::GRAPHIC_THREAD_INTERFACE: return m_pHapticDeviceGT;
        default: return 0;

    }
}

const IHapticDevice * const HapticDeviceManager::getHapticDevice(
    IHapticDevice::InterfaceType type) const
{
    switch (type)
    {
        case IHapticDevice::HAPTIC_THREAD_INTERFACE: return m_pHapticDeviceHT;
        case IHapticDevice::GRAPHIC_THREAD_INTERFACE: return m_pHapticDeviceGT;
        default: return 0;

    }
}

/******************************************************************************
 Servoloop Scheduler Callbacks
******************************************************************************/
HDCallbackCode HDCALLBACK HapticDeviceManager::deviceUpdateCallback(
    void *pUserData)
{
    HapticDeviceManager *pThis = static_cast<HapticDeviceManager *>(pUserData);
   
    /* Force the haptic device to update its state. */
    pThis->m_pHapticDeviceHT->beginUpdate(0);

    IHapticDevice::IHapticDeviceState *pState = 
        pThis->m_pHapticDeviceHT->getCurrentState();

    hduVector3Dd devicePositionLC = pState->getPosition();   
    hduVector3Dd proxyPosLC;

    if (pThis->isManipulating())
    {
        /* The proxy is updated by the ODE simulation. */
        proxyPosLC = pState->getProxyPosition();
        pState->setIsInContact(true);
        pState->setContactData(0);
    }
    else
    {
        proxyPosLC = devicePositionLC;
        pState->setProxyPosition(proxyPosLC);
        pState->setIsInContact(false);
        pState->setContactData(0);
    }

    hdGetDoublev(HD_CURRENT_TRANSFORM, pState->getProxyTransform());
    pState->getProxyTransform()[12] = proxyPosLC[0];
    pState->getProxyTransform()[13] = proxyPosLC[1];
    pState->getProxyTransform()[14] = proxyPosLC[2];
    
    /* Compute spring force to attract device to constrained proxy. */
    double kStiffness = 0.2;
    hduVector3Dd force = kStiffness * (proxyPosLC - devicePositionLC);
    hdSetDoublev(HD_CURRENT_FORCE, force);

    pThis->m_pHapticDeviceHT->endUpdate(0);

    return HD_CALLBACK_CONTINUE;
}

HDCallbackCode HDCALLBACK HapticDeviceManager::setHapticDeviceWorkspace(
    void *pUserData)
{
    HapticDeviceManager *pThis = static_cast<HapticDeviceManager *>(pUserData);

    IHapticDevice::IHapticDeviceState *pStateGT = 
        pThis->m_pHapticDeviceGT->getCurrentState();
    IHapticDevice::IHapticDeviceState *pStateHT = 
        pThis->m_pHapticDeviceHT->getCurrentState();

    /* Apply offsetXform to the workspaceXform. */
    hduMatrix cumXform;
    cumXform = pThis->m_offsetXform;
    cumXform.multRight(pThis->m_workspaceXform);

    pStateGT->setParentCumulativeTransform(cumXform);
    pStateHT->setParentCumulativeTransform(cumXform);

    return HD_CALLBACK_DONE;
}

void HapticDeviceManager::updateSimulation()
{
    /* Capture the latest state from the servoloop. */
    m_pHapticDeviceGT->beginUpdate(m_pHapticDeviceHT);
    m_pHapticDeviceGT->endUpdate(m_pHapticDeviceHT);

    updateWorkspace();
    updateManipulation();
}

void HapticDeviceManager::updateDisplay()
{
    IHapticDevice::IHapticDeviceState *pState = m_pHapticDeviceGT->getCurrentState();
    
    hduVector3Dd cursorPosLC = pState->getProxyPosition();
    hduVector3Dd cursorPosWC;
    
    hduMatrix parentTworld(pState->getParentCumulativeTransform());
    parentTworld.multVecMatrix(cursorPosLC, cursorPosWC);
       
    /* No need for rotation for this demo. */
    static const double R[12] =
    {
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0
    };

    dsSetColor (1,1,1);
    dsSetTexture (DS_NONE);
    dsDrawSphereD(cursorPosWC, R, CURSOR_RADIUS);
}

void HapticDeviceManager::updateWorkspace()
{
    ViewpointState tempView;
    dsGetViewpoint(tempView.m_xyz, tempView.m_hpr);

    if (tempView != m_currentView)
    {
        m_currentView = tempView;

        HDdouble modelview[16];
        HDdouble projection[16];
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
        glGetDoublev(GL_PROJECTION_MATRIX, projection);

        double zNear = 0.9;
        double zFar = 0.97;
        hduMapWorkspaceModelEx(modelview, projection, zNear, zFar, m_workspaceXform);        

        /* Handle setting the workspace transform on the device. */
        hdScheduleSynchronous(setHapticDeviceWorkspace, this,
                              HD_MIN_SCHEDULER_PRIORITY);         
    }
}


HDCallbackCode HapticDeviceManager::startManipulationCallback(void *pUserData)
{
    HapticDeviceManager *pThis = static_cast<HapticDeviceManager *>(pUserData);
    pThis->m_bManipulating = true;
    setHapticDeviceWorkspace(pThis);

    return HD_CALLBACK_DONE;
}


HDCallbackCode HDCALLBACK HapticDeviceManager::stopManipulationCallback(
    void *pUserData)
{
    HapticDeviceManager *pThis = static_cast<HapticDeviceManager *>(pUserData);
    pThis->m_bManipulating = false; 
    pThis->m_offsetXform.makeIdentity();
    setHapticDeviceWorkspace(pThis);    

    return HD_CALLBACK_DONE;
}

HDCallbackCode HDCALLBACK HapticDeviceManager::updateManipulationCallback(
    void *pUserData)
{
    HapticDeviceManager *pThis = static_cast<HapticDeviceManager *>(pUserData);
    
    if (pThis->isManipulating())
    {
        // Update the position of the proxy. We can synchronously access the
        // HapticDeviceGT state to get it.    
        pThis->m_pHapticDeviceHT->getCurrentState()->setProxyPosition(
            pThis->m_pHapticDeviceGT->getCurrentState()->getProxyPosition());   
    }

    return HD_CALLBACK_DONE;
}

void HapticDeviceManager::buttonDownCallbackHT(IHapticDevice::EventType event,
                                               const IHapticDevice::IHapticDeviceState * const pState,
                                               void *pUserData)
{
}

void HapticDeviceManager::buttonDownCallbackGT(IHapticDevice::EventType event,
                                               const IHapticDevice::IHapticDeviceState * const pState,
                                               void *pUserData)
{      
    HapticDeviceManager *pThis = static_cast<HapticDeviceManager *>(pUserData);

    pThis->startManipulation(pState);
}

void HapticDeviceManager::buttonUpCallbackGT(IHapticDevice::EventType event,
                                             const IHapticDevice::IHapticDeviceState *pState,
                                             void *pUserData)
{
    HapticDeviceManager *pThis = static_cast<HapticDeviceManager *>(pUserData);    

    pThis->stopManipulation();
}

void HapticDeviceManager::startManipulation(
    const IHapticDevice::IHapticDeviceState *pState)
{
    if (isManipulating())
        return;
        
    hduVector3Dd devicePosWC;
    hduMatrix parentTworld(pState->getParentCumulativeTransform());    
    hduMatrix worldTparent = parentTworld.getInverse();
    parentTworld.multVecMatrix(pState->getPosition(), devicePosWC);    

    /* Find the closest body to the sampled haptic device position and
       attach a spring to it. */
    int numGeom = dSpaceGetNumGeoms(m_space);
    dsPrint("Searching through %d geom for closest one\n", numGeom);

    double minDistSqr = DBL_MAX;

    for (int i = 0; i < numGeom; i++)
    {
        dGeomID geom = dSpaceGetGeom(m_space, i);
        dBodyID bodyId = dGeomGetBody(geom);
        if (bodyId)
        {
            const dReal *geomPosWC = dGeomGetPosition(geom);

            if (geomPosWC)
            {        
                HDdouble distSqr = 0;
                distSqr += (geomPosWC[0] - devicePosWC[0]) * (geomPosWC[0] - devicePosWC[0]);
                distSqr += (geomPosWC[1] - devicePosWC[1]) * (geomPosWC[1] - devicePosWC[1]);
                distSqr += (geomPosWC[2] - devicePosWC[2]) * (geomPosWC[2] - devicePosWC[2]);
            
                if (distSqr < minDistSqr)
                {
                    minDistSqr = distSqr;
                    m_geom = geom;
                }
            }
        }
    }  

    /* Determine the offset to use based on the position from the event.
       Need to determine position of geometry in parent coordinates. */
    hduVector3Dd geomPosLC, offsetLC;
    const dReal *geomPosWC = dGeomGetPosition(m_geom);
    geomPosLC[0] = geomPosWC[0];
    geomPosLC[1] = geomPosWC[1];
    geomPosLC[2] = geomPosWC[2];
    worldTparent.multVecMatrix(geomPosLC, geomPosLC);
    offsetLC = geomPosLC - pState->getPosition();   
    m_offsetXform = hduMatrix::createTranslation(offsetLC);

    hdScheduleSynchronous(startManipulationCallback, this,
                          HD_DEFAULT_SCHEDULER_PRIORITY);
}

void HapticDeviceManager::stopManipulation()
{
    if (!isManipulating())
        return;

    hdScheduleSynchronous(stopManipulationCallback, this,
                          HD_DEFAULT_SCHEDULER_PRIORITY);
}

void HapticDeviceManager::updateManipulation()
{
    if (!isManipulating())
        return;

    IHapticDevice::IHapticDeviceState *pState = m_pHapticDeviceGT->getCurrentState();

    /* Update the position of the haptic device body. */
    hduVector3Dd devicePosWC;
    hduMatrix parentTworld(pState->getParentCumulativeTransform());    
    parentTworld.multVecMatrix(pState->getPosition(), devicePosWC);

    /* Apply a spring force that will attract the geom body towards the device 
       position. */
    const double kStiffness = 15.0;
    dBodyID geomBody = dGeomGetBody(m_geom);
    hduVector3Dd bodyPosWC(dBodyGetPosition(geomBody)); 
    hduVector3Dd geomForce = kStiffness * (devicePosWC - bodyPosWC);
    dBodyAddForce(geomBody, geomForce[0], geomForce[1], geomForce[2]);
    
    /* Set the proxy position for the graphics side first, and then sync
       it with the haptics side. The proxy position is the position of
       the manipulated geom. */
    hduMatrix worldTparent = parentTworld;
    bool bNoError = worldTparent.invert();
    assert(bNoError);

    hduVector3Dd bodyPosLC;
    bodyPosLC[0] = bodyPosWC[0];
    bodyPosLC[1] = bodyPosWC[1];
    bodyPosLC[2] = bodyPosWC[2];
    worldTparent.multVecMatrix(bodyPosLC, bodyPosLC);
    
    pState->setProxyPosition(bodyPosLC);

    hdScheduleSynchronous(updateManipulationCallback, this,
                          HD_DEFAULT_SCHEDULER_PRIORITY);
}

/******************************************************************************/
