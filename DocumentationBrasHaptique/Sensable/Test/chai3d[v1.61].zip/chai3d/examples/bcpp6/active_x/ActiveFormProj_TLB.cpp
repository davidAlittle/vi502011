// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// C++ TLBWRTR : $Revision: 1.18 $
// File generated on 4/25/2007 1:09:33 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\Documents and Settings\francois\Desktop\chai3d\examples\bcpp6\active_x\ActiveFormProj.tlb (1)
// LIBID: {F1238B58-47BB-4D14-BFD2-315846C966A7}
// LCID: 0
// Helpfile: 
// HelpString: ActiveFormProj Library
// DepndLst: 
//   (1) v2.0 stdole, (C:\WINDOWS\system32\stdole2.tlb)
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include "ActiveFormProj_TLB.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Activeformproj_tlb
{


// *********************************************************************//
// GUIDS declared in the TypeLibrary                                      
// *********************************************************************//
//*********************************************************************//
// NOTE: This file is no longer used. GUIDS previously defined in this 
// file are now defined in the header itself, using __declspec(selectany).
//********************************************************************//

};     // namespace Activeformproj_tlb
