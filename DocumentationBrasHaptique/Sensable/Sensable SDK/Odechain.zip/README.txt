Haptic ODE Chain Demo
---------------------

This sample demonstrates integrating SensAble Technologies HDAPI library with the
Open Dynamics Engine.  HDAPI is used to add haptic interaction to this ODE sample
program.  Hold down the button on the haptic device to "grab" the chain of linked
spheres and move them around.

Requirements:
PHANToM(TM) haptic device.
HDAPI version 1.0 or 1.01
ODE version 0.5 


Building the demo 
-----------------

This example can be linked with ODE version 0.5.  This example requires not
only the ODE library, ode.lib, but also the ODE utility "drawstuff", which 
is included in the ODE source distribution.  

The Haptic ODE Chain Demo links with ode.lib (Release), oded.lib (Debug), 
and drawstuff.lib (both Release and Debug).  The Haptic ODE Chain Demo 
project must include the file resources.rc from the drawstuff src directory.

Lastly, the path to the drawstuff textures has to be hard coded into 
the main() function for this demo.  This is so that the ODE drawstuff utility
can find the appropriate image files for textures.  In the file main.cpp 
in the Haptic ODE Chain demo look for the initialization of the dsFunctions
struct a few lines into main().  Set the dsFunctions::path_to_textures
field to the correct path for the ODE drawstuff textures. 

Visual C++ 6 files are included with this demo, and these can be easily
converted by Visual C++ .NET.

The project files for this demo, OdeChain.dsw and OdeChain.dsp, are set
up for a configuration where the ODE directory is a in the same directory
as the project files.

The project file (.dsw and .dsp) included with the Haptic ODE Chain demo 
assume that the ODE distribution is in a subdirectory named "ode" in the
same directory as the project files. 

I.e., the assumed directory structure is:

<demo directory>
 	OdeChain.dsw
	OdeChain.dsp
	src // OdeChain sources
	include // OdeChain headers
	ode // ODE distribution

If your ODE distribution is somewhere else, you can change the include
paths, library paths, and path to the drawstuff resources.rc file to 
point to the appropriate locations.
	


Legal:

The Open Dynamics Engine is a copyrightable work of the Open Dynamics Engine, 
Copyright (C) 2001,2002 Russell L. Smith.
* All rights reserved.  Email: russ@q12.org   Web: www.q12.org      

Neither the names of ODE's copyright owner nor the names of its contributors 
may be used to endorse or promote products derived from this software without
specific prior written permission. 

THE modified ODE SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE. 

This file has been modified by SensAble Technologies, Inc. (STI) to provide an
example of how to incorporate STI's proprietary technology into existing 
applications. 

You may not combine the STI software with other software that is
licensed pursuant to terms that require that the licensed STI software
be licensed or shared with others. This library is distributed utilizing a 
BSD-style license that does not change STI's rights and privileges of its 
proprietary technology.
