/******************************************************************************

Copyright (c) 2004 SensAble Technologies, Inc. All rights reserved.

3D Touch(TM) SDK, HDAPI Source Code Examples. The material embodied in
this software and use of this software is subject to the terms and
conditions of the clickthrough Development License Agreement.

Send your questions, comments or bugs to: support@sensable.com

Module name:

  IHapticDeviceManager.h

Description:

  Haptic Device Manager class header file.

*******************************************************************************/


#ifndef IHapticDeviceManager_H_
#define IHapticDeviceManager_H_

#include <HDU\hduHapticDevice.h>

#include <ODE\ode.h>

class IHapticDeviceManager
{
public:

    static IHapticDeviceManager *create();
    static void destroy(IHapticDeviceManager *&pInterface);

    virtual bool init(dWorldID world, dSpaceID space) = 0;
    virtual bool shutdown() = 0;

    virtual void updateSimulation() = 0;
    virtual void updateDisplay() = 0;

    virtual bool isManipulating() const = 0;

    virtual IHapticDevice * const getHapticDevice(IHapticDevice::InterfaceType type) 
        = 0;
    virtual const IHapticDevice * const getHapticDevice(IHapticDevice::InterfaceType type) 
        const = 0;

    

protected:
    IHapticDeviceManager() {}
    virtual ~IHapticDeviceManager() {}
};

#endif /* IHapticDeviceManager_H_ */

/*******************************************************************************/
