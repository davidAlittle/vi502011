//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dynamic_ode.rc
//
#define IDD_dynamic_ode_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_GL_AREA                     1001
#define IDC_CHECK_WIREFRAME             1002
#define IDC_CHECK_SHOWFRAME             1003
#define IDC_CHECK_SHOWBOX               1004
#define IDC_CHECK_SHOWNORMALS           1005
#define IDC_CHECK_SHOWCOLDET            1006
#define IDC_CHECK_USETEXTURE            1007
#define IDC_CHECK_USECOLORS             1008
#define IDC_CHECK_MATERIAL              1009
#define IDC_CHECK_CULLING               1010
#define IDC_LOAD_MODEL_BUTTON           1011
#define IDC_LOAD_TEXTURE_BUTTON         1012
#define IDC_CHECK_CULLING2              1013
#define IDC_CHECK_TRANSPARENCY          1013
#define IDC_CAMZOOM_SLIDER              1015
#define IDC_TOGGLEHAPTICS_BUTTON        1016
#define IDC_STIFFNESS_SLIDER            1017
#define IDC_STATICFRICTION_SLIDER       1018
#define IDC_DYNAMIC_FRICTION_SLIDER     1019
#define IDC_STIFFNESS_TEXT              1020
#define IDC_STATICFRICTION_TEXT         1021
#define IDC_DYNAMIC_FRICTION_RADIUS_TEXT 1022
#define IDC_TOGGLE_STEREO_BUTTON        1023
#define IDC_SECOND_DEVICE_BUTTON        1025
#define IDC_STATIC3                     1026
#define IDC_STATIC4                     1027
#define IDC_STEREOFOCUS_SLIDER          1028
#define IDC_STEREOFOCUS_TEXT            1029
#define IDC_STEREOSEP_SLIDER            1030
#define IDC_STEREOSEP_TEXT              1031
#define IDC_STATIC5                     1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
