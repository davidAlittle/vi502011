//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by force_shading.rc
//
#define IDD_force_shading_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_GL_AREA                     1001
#define IDC_CHECK_WIREFRAME             1002
#define IDC_CHECK_SHOWFRAME             1003
#define IDC_CHECK_SHOWBOX               1004
#define IDC_CHECK_SHOWNORMALS           1005
#define IDC_CHECK_SHOWCOLDET            1006
#define IDC_CHECK_USETEXTURE            1007
#define IDC_CHECK_USECOLORS             1008
#define IDC_CHECK_MATERIAL              1009
#define IDC_CHECK_CULLING               1010
#define IDC_LOAD_MODEL_BUTTON           1011
#define IDC_LOAD_TEXTURE_BUTTON         1012
#define IDC_CAMZOOM_SLIDER              1015
#define IDC_TOGGLEHAPTICS_BUTTON        1016
#define IDC_STATIC1                     1017
#define IDC_CHECK1                      1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
