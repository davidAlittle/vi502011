//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by math.rc
//
#define IDD_math_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_GL_AREA                     1001
#define IDC_CHECK_WIREFRAME             1002
#define IDC_CHECK_SHOWFRAME             1003
#define IDC_CHECK_SHOWBOX               1004
#define IDC_CHECK_SHOWNORMALS           1005
#define IDC_CHECK_SHOWCOLDET            1006
#define IDC_CHECK_USETEXTURE            1007
#define IDC_CHECK_USECOLORS             1008
#define IDC_CHECK_MATERIAL              1009
#define IDC_CHECK_CULLING               1010
#define IDC_LOAD_MODEL_BUTTON           1011
#define IDC_LOAD_TEXTURE_BUTTON         1012
#define IDC_CAMZOOM_SLIDER              1015
#define IDC_TOGGLEHAPTICS_BUTTON        1016
#define IDC_EDIT1                       1018
#define IDC_EDIT2                       1019
#define IDC_EDIT3                       1020
#define IDC_EDIT4                       1021
#define IDC_EDIT5                       1022
#define IDC_EDIT6                       1023
#define IDC_EDIT7                       1024
#define IDC_EDIT8                       1025
#define IDC_EDIT9                       1026
#define IDC_EDIT10                      1027
#define IDC_EDIT11                      1028
#define IDC_EDIT12                      1029
#define IDC_EDIT13                      1030
#define IDC_EDIT14                      1031
#define IDC_EDIT15                      1032
#define IDC_EDIT16                      1033
#define IDC_EDIT17                      1034
#define IDC_EDIT18                      1035
#define IDC_EDIT19                      1036
#define IDC_EDIT20                      1037
#define IDC_EDIT21                      1038
#define IDC_EDIT22                      1039
#define IDC_EDIT23                      1040
#define IDC_EDIT24                      1041
#define IDC_EDIT25                      1042
#define IDC_EDIT26                      1043
#define IDC_EDIT27                      1044
#define IDC_EDIT28                      1045
#define IDC_EDIT29                      1046
#define IDC_EDIT30                      1047
#define IDC_EDIT31                      1048
#define IDC_EDIT32                      1049
#define IDC_EDIT33                      1050
#define IDC_EDIT34                      1051
#define IDC_EDIT35                      1052
#define IDC_EDIT36                      1053
#define IDC_BUTTON5                     1059
#define IDC_BUTTON6                     1060
#define IDC_BUTTON7                     1061
#define IDC_BUTTON8                     1062
#define IDC_BUTTON9                     1063
#define IDC_BUTTON10                    1064
#define IDC_BUTTON11                    1065
#define IDC_BUTTON12                    1066
#define IDC_BUTTON13                    1067
#define IDC_EDIT37                      1068
#define IDC_BUTTON14                    1069
#define IDC_BUTTON15                    1070
#define IDC_BUTTON16                    1071
#define IDC_BUTTON17                    1072
#define IDC_BUTTON19                    1074
#define IDC_BUTTON20                    1075
#define IDC_BUTTON21                    1076
#define IDC_BUTTON22                    1077
#define IDC_EDIT38                      1078

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1069
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
